package edu.gsu.httpscs.yanaudioplayer.audio;

/**
 * Created by Yan on 3/15/17.
 */

public class BaseAudioOb {
    private String URL;

    public String getURL() {
        return URL;
    }

    public void setURL(String URL) {
        this.URL = URL;
    }
}
